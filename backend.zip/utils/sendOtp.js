// require('dotenv').config();
// const twilio = require('twilio');

// const accountSid = process.env.TWILIO_ACCOUNT_SID;
// const apiKeySid = process.env.TWILIO_API_KEY_SID;
// const apiKeySecret = process.env.TWILIO_API_KEY_SECRET;

// const client = twilio(apiKeySid, apiKeySecret, { accountSid });

// const sendOtp = async (contactNumber, otp) => {
//   try {
//     console.log(`Attempting to send OTP to ${contactNumber} from ${process.env.TWILIO_PHONE_NUMBER}`);
//     const message = await client.messages.create({
//       body: `Your OTP code is ${otp}`,
//       from: process.env.TWILIO_PHONE_NUMBER,
//       to: contactNumber,
//     });
//     console.log(`OTP sent successfully: ${message.sid}`);
//   } catch (error) {
//     console.error(`Failed to send OTP: ${error.message}`);
//     throw new Error('Failed to send OTP');
//   }
// };

// module.exports = { sendOtp };
