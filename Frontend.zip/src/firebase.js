import firebase from 'firebase/app'
import 'firebase/auth'

var firebaseConfig = {
  apiKey: "AIzaSyCznCxJk0bhQ537phicjIn4otfKD3W8A-s",
  authDomain: "igalaxy-45327.firebaseapp.com",
  projectId: "igalaxy-45327",
  storageBucket: "igalaxy-45327.appspot.com",
  messagingSenderId: "485876851171",
  appId: "1:485876851171:web:7ba17bf7aea1653388c0d6"
  };
  // Initialize Firebase
  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }
  
export default firebase
