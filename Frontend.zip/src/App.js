import React from 'react';
import axios from 'axios';
import firebase from './firebase'; // Make sure Firebase is initialized in this file

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      email: '',
      password: '',
      mobile: '',
      otp: '',
      isOtpSent: false,
    };
  }

  handleChange = (e) => {
    const { name, value } = e.target;
    this.setState({
      [name]: value,
    });
  };

  configureCaptcha = () => {
    window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('sign-in-button', {
      'size': 'invisible',
      'callback': (response) => {
        this.onSignInSubmit();
        console.log("Recaptcha verified");
      },
      'defaultCountry': 'IN',
    });
  };

  onSignInSubmit = (e) => {
    e.preventDefault();
    this.configureCaptcha();
    const phoneNumber = "+91" + this.state.mobile;
    console.log(phoneNumber);
    const appVerifier = window.recaptchaVerifier;

    firebase.auth().signInWithPhoneNumber(phoneNumber, appVerifier)
      .then((confirmationResult) => {
        window.confirmationResult = confirmationResult;
        this.setState({ isOtpSent: true });
        console.log("OTP has been sent");
      }).catch((error) => {
        console.log("SMS not sent", error);
      });
  };

  onSubmitOTP = (e) => {
    e.preventDefault();
    const code = this.state.otp;
    console.log(code);

    window.confirmationResult.confirm(code).then(async (result) => {
      const user = result.user;
      console.log(JSON.stringify(user));
      alert("User is verified");

      // Register the user in your backend
      const { name, email, password, mobile } = this.state;
      try {
        const response = await axios.post('http://localhost:5000/api/users', {
          name,
          email,
          password,
          contactNumber: mobile,
        });
        console.log(response.data);
        alert('User registered successfully');
      } catch (error) {
        console.error(error);
        alert('Error registering user');
      }
    }).catch((error) => {
      console.log("Incorrect OTP", error);
    });
  };

  render() {
    const { isOtpSent } = this.state;

    return (
      <div>
        <h2>Register Form</h2>
        <form onSubmit={this.onSignInSubmit}>
          <div id="sign-in-button"></div>
          <input
            type="text"
            name="name"
            placeholder="Name"
            required
            onChange={this.handleChange}
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            required
            onChange={this.handleChange}
          />
          <input
            type="password"
            name="password"
            placeholder="Password"
            required
            onChange={this.handleChange}
          />
          <input
            type="number"
            name="mobile"
            placeholder="Mobile number"
            required
            onChange={this.handleChange}
          />
          <button type="submit" disabled={isOtpSent}>Submit</button>
        </form>

        {isOtpSent && (
          <div>
            <h2>Enter OTP</h2>
            <form onSubmit={this.onSubmitOTP}>
              <input
                type="number"
                name="otp"
                placeholder="OTP Number"
                required
                onChange={this.handleChange}
              />
              <button type="submit">Submit</button>
            </form>
          </div>
        )}
      </div>
    );
  }
}

export default App;
